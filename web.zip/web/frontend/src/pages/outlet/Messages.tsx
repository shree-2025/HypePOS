export { default } from '@/pages/distributor/Messages'
