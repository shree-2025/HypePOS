export { default } from '@/pages/distributor/Reports'
