export { default } from '@/pages/OutletDashboard'
