export { default } from '@/pages/Sales'
