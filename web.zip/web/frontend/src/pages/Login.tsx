import { useState } from 'react'
import Input from '@/components/ui/Input'
import Button from '@/components/ui/Button'
import Skeleton from '@/components/feedback/Skeleton'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth'
import api from '@/api/axios'
import { useOrg } from '@/context/org'
import logo from '@/public/hype_logo.png'

export default function Login() {
  const nav = useNavigate()
  const { login, loading } = useAuth()
  const { setRole, outlets, setOutlets, selectedOutletId, setSelectedOutletId } = useOrg()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({})
  const [roleChoice, setRoleChoice] = useState<'master' | 'admin' | 'distributor' | 'salers'>('master')

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const errs: typeof errors = {}
    if (!email) errs.email = 'Email is required'
    if (!password) errs.password = 'Password is required'
    setErrors(errs)
    if (Object.keys(errs).length) return
    const result = await login(email, password, roleChoice)
    if (result.ok) {
      // If first login with temporary password, force reset
      if (result.mustChangePassword) {
        return nav('/reset-password')
      }
      // Map selected role to org role; for Sales, grant distributor-level access
      if (roleChoice === 'salers') setRole('distributor')
      else setRole(roleChoice)
      // Auto-select outlet for Outlet Admin by email
      if (roleChoice === 'admin') {
        try {
          const { data } = await api.get('/api/outlets', { params: { email } })
          if (Array.isArray(data) && data.length) {
            const list = data.map((o: any) => ({ id: String(o.id), name: o.name, code: o.code }))
            setOutlets(list)
            setSelectedOutletId(String(list[0].id))
          }
        } catch {}
      } else if ((roleChoice === 'distributor' || roleChoice === 'salers') && !selectedOutletId) {
        setSelectedOutletId(outlets[1]?.id || outlets[0]?.id)
      }
      nav(roleChoice === 'salers' ? '/sales' : '/dashboard')
    }
  }

  const quickLogin = async (role: 'master' | 'admin' | 'distributor' | 'salers') => {
    setRoleChoice(role)
    setEmail(
      role === 'master'
        ? 'master@demo.com'
        : role === 'admin'
        ? 'admin@demo.com'
        : role === 'distributor'
        ? 'distributor@demo.com'
        : 'sales@demo.com'
    )
    setPassword('password')
  }

  return (
    <div className="min-h-screen bg-surface">
      <div className="grid min-h-screen grid-cols-1 lg:grid-cols-2">
        {/* Left: brand + side image */}
        <div className="relative hidden items-center justify-center bg-headerBlue p-8 text-white lg:flex">
          <div className="absolute inset-0 opacity-10" style={{backgroundImage:'radial-gradient(circle at 20% 20%, #fff 2px, transparent 2px), radial-gradient(circle at 80% 30%, #fff 2px, transparent 2px)', backgroundSize:'60px 60px'}} />
          <div className="relative z-10 max-w-sm text-center">
            {/* Brand logo */}
            <img src={logo} alt="HypePOS" className="mx-auto mb-4 h-16 w-16 object-contain" />
            <h1 className="mb-2 text-2xl font-semibold">HYPEPOS</h1>
            <p className="text-white/80">Multi-outlet Point of Sale with centralized inventory and reporting.</p>
            {/* Side image mock (dummy image) */}
            <img
              src="https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop"
              alt="Retail illustration"
              className="mt-8 h-64 w-full rounded-xl object-cover ring-1 ring-white/20"
              loading="eager"
            />
          </div>
        </div>

        {/* Right: card with image + form */}
        <div className="flex items-center justify-center p-6">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-soft">
            {/* Card top: small image */}
            <div className="mb-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img src={logo} alt="HypePOS" className="h-10 w-10 object-contain" />
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-500">Welcome</div>
                  <div className="text-base font-semibold text-gray-900">Sign in to continue</div>
                </div>
              </div>
              {/* decorative card image (dummy) */}
              <img
                src="https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=400&auto=format&fit=crop"
                alt="Dashboard preview"
                className="h-12 w-20 rounded-md object-cover"
              />
            </div>

            {loading ? (
              <div className="space-y-3">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : (
              <form className="space-y-4" onSubmit={onSubmit}>
                {/* Role dropdown */}
                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">Role</label>
                  <select
                    className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-black focus:outline-none"
                    value={roleChoice}
                    onChange={(e) => setRoleChoice(e.target.value as any)}
                  >
                    <option value="master">Master Head Office </option>
                    <option value="distributor">Distribution Center</option>
                    <option value="admin">POS</option>
                    <option value="salers">Sales</option>
                  </select>
                </div>

                {/* Outlet selector removed per request; default outlet set automatically on submit */}

                <Input
                  type="email"
                  label="Email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  error={errors.email}
                />
                <Input
                  type={showPass ? 'text' : 'password'}
                  label="Password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  error={errors.password}
                  rightIcon={
                    <button
                      type="button"
                      onClick={() => setShowPass((v) => !v)}
                      className="p-1 focus:outline-none focus:ring-2 focus:ring-primary-300 rounded"
                      aria-label={showPass ? 'Hide password' : 'Show password'}
                      title={showPass ? 'Hide password' : 'Show password'}
                    >
                      {showPass ? (
                        // Eye off icon
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20C7 20 2.73 16.11 1 12c.62-1.44 1.5-2.75 2.57-3.86" />
                          <path d="M10.58 10.58a2 2 0 0 0 2.84 2.84" />
                          <path d="M23 12c-.62 1.44-1.5 2.75-2.57 3.86" />
                          <path d="M14.12 14.12 20 20" />
                          <path d="M3 3l5.88 5.88" />
                        </svg>
                      ) : (
                        // Eye icon
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z" />
                          <circle cx="12" cy="12" r="3" />
                        </svg>
                      )}
                    </button>
                  }
                />
                <Button type="submit" className="w-full" loading={loading}>
                  Sign In
                </Button>

                {/* Demo logins */}
                <div className="mt-2 grid grid-cols-4 gap-2 text-xs">
                  <Button type="button" variant="outline" onClick={() => quickLogin('master')}>Demo Master</Button>
                  <Button type="button" variant="outline" onClick={() => quickLogin('admin')}>Demo Outlet Admin</Button>
                  <Button type="button" variant="outline" onClick={() => quickLogin('distributor')}>Demo Distributor</Button>
                  <Button type="button" variant="outline" onClick={() => quickLogin('salers')}>Demo Sales</Button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
