export type Role = 'cashier' | 'manager' | 'admin'
